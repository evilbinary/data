# logger
Logger library for R7RS Scheme

The Logger library can be used to output messages to an output port.  
Each message is given a level, and only messages above a certain set 
level will be output to the port.  This allows the developer to control
the level of detail output by the program.  
This logger library uses the same levels as Ruby's Logger class.
